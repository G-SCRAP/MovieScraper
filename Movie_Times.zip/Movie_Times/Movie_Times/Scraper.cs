﻿//Gavin Ogren
//12/2/2021
//Scrapes Websties based on locations

using System;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Web;
using System.Diagnostics;

namespace Movie_Times
{
    public class Scraper
    {
        public List<MovieTimeModel> _Movies = new List<MovieTimeModel>();

        public List<MovieTimeModel> Movies
        {
            get { return _Movies; }
            set { _Movies = value; }
        }
        public void ScrapeData(string webpage)
        {
            var web = new HtmlWeb();
            var doc = web.Load(webpage);
      

            //Articles will get each HTML element in the website with the same tag.
            var Articles = doc.DocumentNode.SelectNodes("//*[@class = 'col-full movie-wrapper']");
            
            foreach (var movie in Articles)
            {
                string moviedata = "";

                var Title = HttpUtility.HtmlDecode(movie.SelectSingleNode(".//h2/a[@href]").InnerText.Trim());
                Console.WriteLine(movie.SelectSingleNode(".//ul[@class='showtimes']").InnerText.Trim());




                Console.WriteLine(Title); 
                moviedata += $"{Title}: ";


                
                Console.ReadLine();
            }

        }
        
    }
}
