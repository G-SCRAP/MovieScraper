﻿//Gavin Ogren
//12/2/2021
//A program that scrapes website data for movie showings
using System;

namespace Movie_Times
{
    class Program
    {
        public static void GetMovieShowings(string Location)
        {
            Scraper scrape;
            scrape = new Scraper();

            //Takes the movie location of choice and will decide which website based on location and call class that scrapes data from the website
            string web; 
            switch (Location)
            {
                case "shea":
                    web = "https://www.harkins.com/locations/shea-14?date=2021-12-6";
                    break;
                   
                case "mills":
                    web = "https://www.harkins.com/locations/arizona-mills-18-w-imax";
                    break;

                case "tempe":
                    web = "https://www.harkins.com/locations/tempe-marketplace-16";
                    break;
                case "chandler":
                    web = "https://www.harkins.com/locations/chandler-crossroads-12";
                    break;
                default:
                    web = "https://www.harkins.com/locations/chandler-crossroads-12?date=2021-12-6";
                    break;

                    

            }
            Console.WriteLine(web);
            scrape.ScrapeData(web); 
        } 
        static void Main(string[] args)
        {
            //Welcomes User and has them input movie theater location
            string Location;
            Console.WriteLine("Enter Movie Theater Lcoation: ");
            Location = Convert.ToString(Console.ReadLine());

            Location = Location.ToLower();

            GetMovieShowings(Location); 

        }
    }
}
