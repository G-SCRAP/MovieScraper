﻿using System;
namespace Movie_Times
{
    public class MovieTimeModel
    {
        public string Title { get; set; }
        public string Movie_Length { get; set; }
        public string Time { get; set; }
        public string Date { get; set; }

        public string Info
        {
            //Returns the info for the showings
            get
            {
                return $"Title {Title}\nMovie Length: {Movie_Length}\nTime: {Time}\nDate: {Date}"; 
            }
        }

    }
}
